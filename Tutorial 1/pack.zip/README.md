# Hello World

This is a simple hello world program.

## Compiling

To compile the program you need to run:
```bash
make
```

## Running

Run either of the following lines, depending on the intended functionality :
```bash
./hello-world
```

```bash
./international-hello-world
```